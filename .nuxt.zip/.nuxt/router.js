import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _5edc0bbf = () => import('..\\src\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)
const _e37ffcd8 = () => import('..\\src\\pages\\martin-rodriguez-celin.vue' /* webpackChunkName: "pages_martin-rodriguez-celin" */).then(m => m.default || m)
const _af114c00 = () => import('..\\src\\pages\\avisos-legales.vue' /* webpackChunkName: "pages_avisos-legales" */).then(m => m.default || m)
const _4473ec71 = () => import('..\\src\\pages\\terminos-y-condiciones.vue' /* webpackChunkName: "pages_terminos-y-condiciones" */).then(m => m.default || m)
const _15141e1a = () => import('..\\src\\pages\\precios.vue' /* webpackChunkName: "pages_precios" */).then(m => m.default || m)
const _4a6a791d = () => import('..\\src\\pages\\opiniones.vue' /* webpackChunkName: "pages_opiniones" */).then(m => m.default || m)
const _25306df2 = () => import('..\\src\\pages\\contacto.vue' /* webpackChunkName: "pages_contacto" */).then(m => m.default || m)
const _dcbbdde0 = () => import('..\\src\\pages\\ejemplos.vue' /* webpackChunkName: "pages_ejemplos" */).then(m => m.default || m)
const _fef284e6 = () => import('..\\src\\pages\\ejemplos\\_servicio\\index.vue' /* webpackChunkName: "pages_ejemplos__servicio_index" */).then(m => m.default || m)
const _26945982 = () => import('..\\src\\pages\\ejemplos\\_servicio\\_sector\\index.vue' /* webpackChunkName: "pages_ejemplos__servicio__sector_index" */).then(m => m.default || m)
const _d602a6f8 = () => import('..\\src\\pages\\ejemplos\\_servicio\\_sector\\_actividad\\index.vue' /* webpackChunkName: "pages_ejemplos__servicio__sector__actividad_index" */).then(m => m.default || m)
const _1fd3f796 = () => import('..\\src\\pages\\ejemplos\\_servicio\\_sector\\_actividad\\_pais\\index.vue' /* webpackChunkName: "pages_ejemplos__servicio__sector__actividad__pais_index" */).then(m => m.default || m)
const _2199c254 = () => import('..\\src\\pages\\ejemplos\\_servicio\\_sector\\_actividad\\_pais\\_localidad.vue' /* webpackChunkName: "pages_ejemplos__servicio__sector__actividad__pais__localidad" */).then(m => m.default || m)
const _39dedb87 = () => import('..\\src\\pages\\area-de-cliente\\index.vue' /* webpackChunkName: "pages_area-de-cliente_index" */).then(m => m.default || m)
const _de262414 = () => import('..\\src\\pages\\finalizar-compra.vue' /* webpackChunkName: "pages_finalizar-compra" */).then(m => m.default || m)
const _7014409b = () => import('..\\src\\pages\\gracias.vue' /* webpackChunkName: "pages_gracias" */).then(m => m.default || m)
const _17383eb8 = () => import('..\\src\\pages\\sobre-liderlogo.vue' /* webpackChunkName: "pages_sobre-liderlogo" */).then(m => m.default || m)
const _1f55ee15 = () => import('..\\src\\pages\\mas-informacion-de-las-cookies.vue' /* webpackChunkName: "pages_mas-informacion-de-las-cookies" */).then(m => m.default || m)
const _572ce2b7 = () => import('..\\src\\pages\\servicios-profesionales.vue' /* webpackChunkName: "pages_servicios-profesionales" */).then(m => m.default || m)
const _531b052e = () => import('..\\src\\pages\\politica-de-cookies.vue' /* webpackChunkName: "pages_politica-de-cookies" */).then(m => m.default || m)
const _3ebb9b90 = () => import('..\\src\\pages\\nuestros-servicios\\index.vue' /* webpackChunkName: "pages_nuestros-servicios_index" */).then(m => m.default || m)
const _27e46642 = () => import('..\\src\\pages\\area-de-cliente\\proyectos\\index.vue' /* webpackChunkName: "pages_area-de-cliente_proyectos_index" */).then(m => m.default || m)
const _3af8b473 = () => import('..\\src\\pages\\area-de-cliente\\entrar.vue' /* webpackChunkName: "pages_area-de-cliente_entrar" */).then(m => m.default || m)
const _20452054 = () => import('..\\src\\pages\\area-de-cliente\\proyectos\\bocetos\\_id.vue' /* webpackChunkName: "pages_area-de-cliente_proyectos_bocetos__id" */).then(m => m.default || m)
const _64177b07 = () => import('..\\src\\pages\\area-de-cliente\\proyectos\\_id.vue' /* webpackChunkName: "pages_area-de-cliente_proyectos__id" */).then(m => m.default || m)
const _66a06507 = () => import('..\\src\\pages\\nuestros-servicios\\_servicio\\index.vue' /* webpackChunkName: "pages_nuestros-servicios__servicio_index" */).then(m => m.default || m)
const _24a189b0 = () => import('..\\src\\pages\\nuestros-servicios\\_servicio\\cotizacion.vue' /* webpackChunkName: "pages_nuestros-servicios__servicio_cotizacion" */).then(m => m.default || m)
const _0070dea2 = () => import('..\\src\\pages\\nuestros-servicios\\_servicio\\brief.vue' /* webpackChunkName: "pages_nuestros-servicios__servicio_brief" */).then(m => m.default || m)
const _2e9ec80d = () => import('..\\src\\pages\\nuestros-servicios\\_servicio\\brief\\_paso.vue' /* webpackChunkName: "pages_nuestros-servicios__servicio_brief__paso" */).then(m => m.default || m)
const _81241230 = () => import('..\\src\\pages\\ejemplo\\_servicio\\_slug.vue' /* webpackChunkName: "pages_ejemplo__servicio__slug" */).then(m => m.default || m)



const scrollBehavior = (to, from, savedPosition) => {
  // SavedPosition is only available for popstate navigations.
  if (savedPosition) {
    return savedPosition
  } else {
    let position = {}
    // If no children detected
    if (to.matched.length < 2) {
      // Scroll to the top of the page
      position = { x: 0, y: 0 }
    }
    else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
      // If one of the children has scrollToTop option set to true
      position = { x: 0, y: 0 }
    }
    // If link has anchor, scroll to anchor by returning the selector
    if (to.hash) {
      position = { selector: to.hash }
    }
    return position
  }
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/",
			component: _5edc0bbf,
			name: "index"
		},
		{
			path: "/martin-rodriguez-celin",
			component: _e37ffcd8,
			name: "martin-rodriguez-celin"
		},
		{
			path: "/avisos-legales",
			component: _af114c00,
			name: "avisos-legales"
		},
		{
			path: "/terminos-y-condiciones",
			component: _4473ec71,
			name: "terminos-y-condiciones"
		},
		{
			path: "/precios",
			component: _15141e1a,
			name: "precios"
		},
		{
			path: "/opiniones",
			component: _4a6a791d,
			name: "opiniones"
		},
		{
			path: "/contacto",
			component: _25306df2,
			name: "contacto"
		},
		{
			path: "/ejemplos",
			component: _dcbbdde0,
			name: "ejemplos",
			children: [
				{
					path: ":servicio",
					component: _fef284e6,
					name: "ejemplos-servicio"
				},
				{
					path: ":servicio/:sector",
					component: _26945982,
					name: "ejemplos-servicio-sector"
				},
				{
					path: ":servicio/:sector/:actividad",
					component: _d602a6f8,
					name: "ejemplos-servicio-sector-actividad"
				},
				{
					path: ":servicio/:sector/:actividad/:pais",
					component: _1fd3f796,
					name: "ejemplos-servicio-sector-actividad-pais"
				},
				{
					path: ":servicio/:sector/:actividad/:pais/:localidad?",
					component: _2199c254,
					name: "ejemplos-servicio-sector-actividad-pais-localidad"
				}
			]
		},
		{
			path: "/area-de-cliente",
			component: _39dedb87,
			name: "area-de-cliente"
		},
		{
			path: "/finalizar-compra",
			component: _de262414,
			name: "finalizar-compra"
		},
		{
			path: "/gracias",
			component: _7014409b,
			name: "gracias"
		},
		{
			path: "/sobre-liderlogo",
			component: _17383eb8,
			name: "sobre-liderlogo"
		},
		{
			path: "/mas-informacion-de-las-cookies",
			component: _1f55ee15,
			name: "mas-informacion-de-las-cookies"
		},
		{
			path: "/servicios-profesionales",
			component: _572ce2b7,
			name: "servicios-profesionales"
		},
		{
			path: "/politica-de-cookies",
			component: _531b052e,
			name: "politica-de-cookies"
		},
		{
			path: "/nuestros-servicios",
			component: _3ebb9b90,
			name: "nuestros-servicios"
		},
		{
			path: "/area-de-cliente/proyectos",
			component: _27e46642,
			name: "area-de-cliente-proyectos"
		},
		{
			path: "/area-de-cliente/entrar",
			component: _3af8b473,
			name: "area-de-cliente-entrar"
		},
		{
			path: "/area-de-cliente/proyectos/bocetos/:id",
			component: _20452054,
			name: "area-de-cliente-proyectos-bocetos-id"
		},
		{
			path: "/area-de-cliente/proyectos/:id?",
			component: _64177b07,
			name: "area-de-cliente-proyectos-id"
		},
		{
			path: "/nuestros-servicios/:servicio?",
			component: _66a06507,
			name: "nuestros-servicios-servicio"
		},
		{
			path: "/nuestros-servicios/:servicio?/cotizacion",
			component: _24a189b0,
			name: "nuestros-servicios-servicio-cotizacion"
		},
		{
			path: "/nuestros-servicios/:servicio?/brief",
			component: _0070dea2,
			name: "nuestros-servicios-servicio-brief",
			children: [
				{
					path: ":paso?",
					component: _2e9ec80d,
					name: "nuestros-servicios-servicio-brief-paso"
				}
			]
		},
		{
			path: "/ejemplo/:servicio?/:slug?",
			component: _81241230,
			name: "ejemplo-servicio-slug"
		}
    ],
    
    
    fallback: false
  })
}
